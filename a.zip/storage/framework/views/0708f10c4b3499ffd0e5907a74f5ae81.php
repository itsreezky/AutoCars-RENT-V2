

  <footer class="footer position-relative">
    <div class="row g-0 justify-content-between align-items-center h-100">
      <div class="col-12 col-sm-auto text-center">
        <p class="mb-0 mt-2 mt-sm-0 text-body">Thank you for visiting<span class="d-none d-sm-inline-block"></span><span class="d-none d-sm-inline-block mx-1">|</span><br class="d-sm-none" />2024 &copy;<a class="mx-1" href="http://itsreezky.my.id">Reezky.</a></p>
      </div>
      <div class="col-12 col-sm-auto text-center">
        <p class="mb-0 text-body-tertiary text-opacity-85"><img src="<?php echo e(asset ('assets/img/reezky/ReezkyLogoNoBG.png')); ?>" alt="reezky" width="150"></p>
      </div>
    </div>
  </footer>
<?php /**PATH /home/reezky/Reezky/LARAVEL/Autocars-RENT/resources/views/Component/public/footer.blade.php ENDPATH**/ ?>