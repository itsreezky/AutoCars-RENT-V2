<!DOCTYPE html>
<html data-navigation-type="default" data-navbar-horizontal-shape="default" lang="en-US" dir="ltr">

<?php if(Auth::user()->status == 'Verified Owner'): ?>

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- ===============================================-->
    <!--                Document Title                  -->
    <!-- ===============================================-->

    <title><?php echo e(Auth::user()->nama); ?> Cars Garage - AutoCars</title>

    <meta name="theme-color" content="#ffffff">

    <!-- ===============================================-->
    <!--                 Stylesheets                    -->
    <!-- ===============================================-->

    <?php echo $__env->make('Component.assets.css-garage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body class="smart-home bg-light-200">


    <!-- ===============================================-->
    <!--                 SweetAlert                    -->
    <!-- ===============================================-->

    <?php echo $__env->make('Component.public.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- ===============================================-->
    <!--                 Garage Navbar                  -->
    <!-- ===============================================-->

    <?php echo $__env->make('Component.garage-studio.garage-navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- ===============================================-->
    <!--                 Garage Modal                   -->
    <!-- ===============================================-->

    <?php echo $__env->make('Component.garage-studio.garage-edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('Component.garage-studio.garage-tambah', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('Component.garage-studio.garage-data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('Component.garage-studio.garage-delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- ===============================================-->
    <!--                Garage Information              -->
    <!-- ===============================================-->

    <?php echo $__env->make('Component.garage-studio.garage-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <div class="card card-body blur shadow-blur mx-3 mx-md-4 mt-n6 mb-4">

        <!-- ===============================================-->
        <!--                Garage Information              -->
        <!-- ===============================================-->

        <?php echo $__env->make('Component.garage-studio.garage-information', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- ===============================================-->
        <!--                 Car Controller                 -->
        <!-- ===============================================-->

        <?php echo $__env->make('Component.garage-studio.garage-carcontroller', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>

    <!-- ===============================================-->
    <!--                 Garage Cam                     -->
    <!-- ===============================================-->

    <?php echo $__env->make('Component.garage-studio.garage-cam', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ===============================================-->
    <!--                    Footer                      -->
    <!-- ===============================================-->

    <?php echo $__env->make('Component.garage-studio.garage-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ===============================================-->
    <!--                   JavaScripts                  -->
    <!-- ===============================================-->

    <?php echo $__env->make('Component.assets.js-garage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

<?php else: ?>

<?php echo $__env->make('Component.public.403', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php endif; ?>

</html>
<?php /**PATH /home/reezky/Reezky/LARAVEL/Autocars-RENT/resources/views/Studio/garage.blade.php ENDPATH**/ ?>