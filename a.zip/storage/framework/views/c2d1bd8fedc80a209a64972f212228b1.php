<!DOCTYPE html>
<html data-navigation-type="default" data-navbar-horizontal-shape="default" lang="en-US" dir="ltr">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- ===============================================-->
    <!--                Document Title                  -->
    <!-- ===============================================-->

    <title>Market - AutoCars</title>

    <meta name="theme-color" content="#ffffff">


    <!-- ===============================================-->
    <!--                 Stylesheets                    -->
    <!-- ===============================================-->

    <?php echo $__env->make('Component.assets.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>


    <!-- ===============================================-->
    <!--                 SweetAlert                    -->
    <!-- ===============================================-->

    <?php echo $__env->make('Component.public.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ===============================================-->
    <!--                   Main Content                 -->
    <!-- ===============================================-->

    <main class="main" id="top">

        <!-- ===============================================-->
        <!--               Section Topbar                   -->
        <!-- ===============================================-->

        <?php echo $__env->make('Component.public.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- ===============================================-->
        <!--                 Section Menu                   -->
        <!-- ===============================================-->

        <div class="ecommerce-homepage pt-2 mb-9">

            <?php echo $__env->make('Component.public.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- ===============================================-->
            <!--               Cars Detail                      -->
            <!-- ===============================================-->

            <?php echo $__env->make('Component.market.cars-detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- ===============================================-->
            <!--              Similar Product                   -->
            <!-- ===============================================-->

            <?php echo $__env->make('Component.market.similar-product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- ===============================================-->
            <!--                 Support Chat                   -->
            <!-- ===============================================-->

            <?php if(Auth::user()): ?>

            <?php echo $__env->make('Component.public.support', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php endif; ?>

        </div>

        <!-- ===============================================-->
        <!--                 About                         -->
        <!-- ===============================================-->

        <?php echo $__env->make('Component.public.about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- ===============================================-->
        <!--                 Footer                         -->
        <!-- ===============================================-->

        <?php echo $__env->make('Component.public.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </main>

    <!-- ===============================================-->
    <!--               Customize WebApps                -->
    <!-- ===============================================-->

    <?php echo $__env->make('Component.public.customize', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ===============================================-->
    <!--                   JavaScripts                  -->
    <!-- ===============================================-->

    <?php echo $__env->make('Component.assets.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH /home/reezky/Reezky/LARAVEL/Autocars-RENT/resources/views/Market/market-detail.blade.php ENDPATH**/ ?>