


    

    <link href="<?php echo e(asset ('assets/css/material-kit-pro.css')); ?>" rel="stylesheet" id="pagestyle" />


    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700%7cPoppins:300,400,500,600,700,800,900&amp;display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" rel="stylesheet" />
    <link href='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.5.0/font/bootstrap-icons.min.css' rel='stylesheet' />
    <link href="https://cdn.datatables.net/v/bs5/dt-1.10.25/datatables.min.css" rel="stylesheet" type="text/css"/>
    
<?php /**PATH /home/reezky/Reezky/LARAVEL/Autocars-RENT/resources/views/Component/assets/css-garage.blade.php ENDPATH**/ ?>