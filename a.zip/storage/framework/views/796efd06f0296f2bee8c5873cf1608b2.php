
    <link href="<?php echo e(asset ('vendors/simplebar/simplebar.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset ('assets/css/theme-rtl.min.css')); ?>" type="text/css" rel="stylesheet" id="style-rtl">
    <link href="<?php echo e(asset ('assets/css/theme.min.css')); ?>" type="text/css" rel="stylesheet" id="style-default">
    <link href="https://unicons.iconscout.com/release/v4.0.8/css/line.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:wght@300;400;600;700;800;900&amp;display=swap" rel="stylesheet">
<?php /**PATH /home/reezky/Reezky/LARAVEL/Autocars-RENT/resources/views/Component/assets/css.blade.php ENDPATH**/ ?>