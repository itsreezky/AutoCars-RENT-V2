<section class="py-0 mt-3">
    <div class="container-small">
        <div class="scrollbar">
            <div class="d-flex justify-content-center">

                <?php if(Auth::user()): ?>

                <a class="icon-nav-item" href="<?php echo e(route('wishlist')); ?>">
                    <div class="icon-container mb-2 bg-warning-subtle light">
                        <span class="fs-4 uil uil-heart text-warning"></span>
                    </div>
                    <p class="nav-label">Wishlist</p>
                </a>

                <a class="icon-nav-item" href="<?php echo e(route('market')); ?>">
                    <div class="icon-container mb-2"><span class="fs-4 uil uil-shop"></span></div>
                    <p class="nav-label">Market</p>
                </a>

                <a class="icon-nav-item" href="<?php echo e(route('profile')); ?>">
                    <div class="icon-container mb-2"><span class="fs-4 uil uil-user"></span></div>
                    <p class="nav-label">Profil</p>
                </a>

                <?php if(Auth::user()->status == 'Regular Member'): ?>
                <a class="icon-nav-item" href="<?php echo e(route('profile')); ?>">
                    <div class="icon-container mb-2"><span class="fs-4 uil uil-user-check mt-1 ms-1"></span></div>
                    <p class="nav-label">Verified</p>
                </a>
                <?php endif; ?>


                <a class="icon-nav-item" href="#settings-offcanvas" data-bs-toggle="offcanvas">
                    <div class="icon-container mb-2"><span class="fs-4 uil uil-palette"></span></div>
                    <p class="nav-label">Customize</p>
                </a>

                <a class="icon-nav-item" href="<?php echo e(route('logout')); ?>" data-confirm-delete="true">
                    <div class="icon-container mb-2"><span class="fs-4 fa-solid fa-arrow-right-from-bracket"></span>
                    </div>
                    <p class="nav-label">Logout</p>
                </a>

                <?php else: ?>

                <a class="icon-nav-item" href="<?php echo e(route('market')); ?>">
                    <div class="icon-container mb-2"><span class="fs-4 uil uil-shop"></span></div>
                    <p class="nav-label">Market</p>
                </a>

                <a class="icon-nav-item" href="#settings-offcanvas" data-bs-toggle="offcanvas">
                    <div class="icon-container mb-2"><span class="fs-4 uil uil-palette"></span></div>
                    <p class="nav-label">Customize</p>
                </a>

                <a class="icon-nav-item" href="<?php echo e(route('register')); ?>" data-confirm-delete="true">
                    <div class="icon-container mb-2"><span class="fs-4 uil uil-user-plus"></span>
                    </div>
                    <p class="nav-label">Register</p>
                </a>

                <a class="icon-nav-item" href="<?php echo e(route('login')); ?>" data-confirm-delete="true">
                    <div class="icon-container mb-2"><span class="fs-4 fa-solid fa-arrow-right-from-bracket"></span>
                    </div>
                    <p class="nav-label">Login</p>
                </a>

                <?php endif; ?>
            </div>
        </div>
</section>
<?php /**PATH /home/reezky/Reezky/LARAVEL/Autocars-RENT/resources/views/Component/public/menu.blade.php ENDPATH**/ ?>