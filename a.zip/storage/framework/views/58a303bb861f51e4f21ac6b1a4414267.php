<!DOCTYPE html>
<html data-navigation-type="default" data-navbar-horizontal-shape="default" lang="en-US" dir="ltr">

<?php if(Auth::user()->status == 'Verified Owner'): ?>

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- ===============================================-->
    <!--                Document Title                  -->
    <!-- ===============================================-->

    <title><?php echo e(Auth::user()->nama); ?> Owner Profile - AutoCars</title>

    <meta name="theme-color" content="#ffffff">

    <!-- ===============================================-->
    <!--                 Stylesheets                    -->
    <!-- ===============================================-->

    <?php echo $__env->make('Component.assets.css-garage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body class="smart-home bg-gray-200">

    <!-- ===============================================-->
    <!--                 SweetAlert                    -->
    <!-- ===============================================-->

    <?php echo $__env->make('Component.public.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ===============================================-->
    <!--                    Modal                       -->
    <!-- ===============================================-->

    <?php echo $__env->make('Component.owner-studio.modal-edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('Component.owner-studio.modal-foto', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ===============================================-->
    <!--                 Information                    -->
    <!-- ===============================================-->

    <?php echo $__env->make('Component.owner-studio.information', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ===============================================-->
    <!--                   JavaScripts                  -->
    <!-- ===============================================-->

    <?php echo $__env->make('Component.assets.js-garage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

<?php else: ?>

<?php echo $__env->make('Component.public.403', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php endif; ?>

</html>
<?php /**PATH /home/reezky/Reezky/LARAVEL/Autocars-RENT/resources/views/Studio/owner.blade.php ENDPATH**/ ?>