<div class="bg-primary-subtle py-2">
    <div class="container-medium d-flex align-items-center justify-content-between"><a
            class="btn btn-link p-0 text-body" href="{{route('ownlogin')}}"><span
                class="fa-solid fa-arrow-right-to-bracket me-2" data-fa-transform="down-1"></span>Cars Owner
            Login</a>
        <div class="dropdown"><button class="btn btn-sm py-0 d-md-none fs-8" type="button"
                data-bs-toggle="dropdown" data-boundary="window" aria-haspopup="true" aria-expanded="false"
                data-bs-reference="parent"><span class="fas fa-ellipsis-h"></span></button>
            <ul class="dropdown-menu dropdown-menu-end" style="z-index: 9999">
                <li><a class="dropdown-item" href="{{route('ownregister')}}">Become a Cars Owner</a></li>
            </ul>
        </div>
        <ul class="d-none d-md-flex gap-5 list-unstyled mb-0">
            <li><a class="lh-1 text-body-tertiary fw-semibold fs-9" href="{{route('ownregister')}}"><span
                        class="fa-regular fa-handshake me-2" data-fa-transform="down-1"></span>Become a Cars
                    Owner</a></li>
            <li><a class="lh-1 text-body-tertiary fw-semibold fs-9" href="http://itsreezky.my.id"><span
                        class="fa-solid fa-earth-asia me-2"
                        data-fa-transform="down-1"></span>www.itsreezky.my.id</a></li>
        </ul>
    </div>
</div>
