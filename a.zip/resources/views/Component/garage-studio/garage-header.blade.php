<header class="bg-gradient-dark">
    <div class="page-header min-vh-50"
        style="background-image: url('https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D');"
        loading="lazy">
        <span class="mask bg-gradient-dark opacity-6"></span>
        <div class="container">


            <div class="row justify-content-center">
                <div class="col-lg-8 text-center mx-auto my-auto">
                    <h2 class="text-white">Hello, {{ Auth::user()->nama }} !</h2>
                    <h2 class="text-white">Welcome To Garage Studio</h2>
                    <p class="lead mb-4 text-white opacity-8">Work Easy With Automotive Rent Apps, We’re constantly
                        trying to express ourselves and
                        actualize our dreams.</p>
                </div>
            </div>
        </div>
    </div>
</header>
