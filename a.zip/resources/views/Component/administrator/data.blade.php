<div class="row g-3 mt-3">
    <center>
        <div class="col-xxl-2 col-xl-4">
            <div class="alert alert-outline-info align-items-center" role="alert">
                <span class="fas fa-info-circle text-info fs-5 me-2 ms-2"></span>
                <p class="mb-0 flex-1">Data Tampil Disini</p>
            </div>
        </div>


    </center>
    <div class="col-xxl-12 col-xl-12">

        <div class="card">
            <div class="card-body">

                <!-- MUNCUL DISINI -->
                <div id="contents"></div>
                <!-- MUNCUL DISINI -->

            </div>
        </div>
    </div>
</div>
</div>
