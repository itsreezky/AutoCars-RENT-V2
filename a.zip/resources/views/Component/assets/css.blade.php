
    <link href="{{asset ('vendors/simplebar/simplebar.min.css') }}" rel="stylesheet">
    <link href="{{asset ('assets/css/theme-rtl.min.css') }}" type="text/css" rel="stylesheet" id="style-rtl">
    <link href="{{asset ('assets/css/theme.min.css') }}" type="text/css" rel="stylesheet" id="style-default">
    <link href="https://unicons.iconscout.com/release/v4.0.8/css/line.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:wght@300;400;600;700;800;900&amp;display=swap" rel="stylesheet">
